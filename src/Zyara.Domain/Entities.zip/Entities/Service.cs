﻿using System;
using System.Collections.Generic;
using System.Text;
using Zyara.Domain.Enums;

namespace Zyara.Domain.Entities
{
    public class Service
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public ServiceType Type { get; set; }
        public bool IsActive { get; set; }

        // Service has many provider services & bookings 
        public List<ProviderService>? ProviderServices { get; set; }
        public List<Booking>? Bookings { get; set; }
    }
}
